// let button = document.getElementById("btn")

// button.addEventListener("click", ()=>{
//     document.querySelector(".qu").innerHTML = "Who is credited with the discovery of the concept of differentiation in calculus? Which mathematicians played a key role in its development, and during which century was it introduced?"
//      document.querySelector(".q1").innerHTML = "QUESTION 2"
// })


// function changecolor(event) {
//     var color = "red";
//     event.style.backgroundColor = color;
// } 
function change() {
  document.getElementById("one").style.backgroundColor = "red";
    document.getElementById("two").style.backgroundColor = "green";   
}
function hange() {
  document.getElementById("three").style.backgroundColor = "red";
    document.getElementById("two").style.backgroundColor = "green";   
}
function ange() {
  document.getElementById("four").style.backgroundColor = "red";
    document.getElementById("two").style.backgroundColor = "green";   
}

function hangecolor(event) {
    var color = "green";
    event.style.backgroundColor = color;
}
// document.getElementsByClassName(".explain").onclick = function () {
//   document.getElementById("ex").innerHTML = "ghghgghgggggggggg"
// }

function text(){
document.getElementById("ex").innerHTML = " EXPLAINATION:-Rafael Bombelli was an Italian mathematician best known for his work on algebra and the introduction of complex numbers. He played a crucial role in making algebra more structured and accessible.Bombelli was among the first mathematicians to systematically use imaginary numbers.He defined 𝑖 i (the square root of -1) and showed how to work with such numbers in equations.His work provided a foundation for later mathematicians like Euler and Gauss."
}                       
// function angecolor(event) {
//     var color = "red";
//     event.style.backgroundColor = color;
// }
// function angecolor(event) {
//     var color = "red";
//     event.style.backgroundColor = color;
// }

// let answer = document.getElementById("btn")

// answer.addEventListener("click", ()=>{
//     document.querySelector(".one").innerHTML = "1: Joost Burgi"
//     document.querySelector(".two").innerHTML = "2: Mahavir"
//     document.querySelector(".three").innerHTML = "3: Newton and Gottfried Wilhelm Leibniz"
//      document.querySelector(".four").innerHTML = "4: Napier John "    
// })
// let butto = document.getElementById("btn")

// butto.addEventListener("dblclick", ()=>{
//     document.querySelector(".qu").innerHTML = "Who is credited with the discovery of the concept of differentiation in calculus? Which mathematicians played a key role in its development, and during which century was it introduced?"
//      document.querySelector(".q1").innerHTML = "QUESTION 3"
// })