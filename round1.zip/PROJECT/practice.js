    // function loadCount() {
    //         let count = localStorage.getItem("clickCount");
    //         if (count === null) {
    //             count = 0;
    //             localStorage.setItem("clickCount", count);
    //         }
    //         document.getElementById("countDisplay").innerText = count;
    //     }

    //     // Function to increment the count
    //     function incrementCount() {
    //         let count = localStorage.getItem("clickCount");
    //         count = parseInt(count) + 10; // Convert to number and increment
    //         localStorage.setItem("clickCount", count); // Store updated count
    //         document.getElementById("countDisplay").innerText = count; // Update display
    //     }

    //     // Load count on page load
//     loadCount();
    





